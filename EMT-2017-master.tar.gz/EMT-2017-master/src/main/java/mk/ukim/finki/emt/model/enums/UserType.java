package mk.ukim.finki.emt.model.enums;

/**
 * @author Riste Stojanov
 */
public enum UserType {
  ADMIN, CUSTOMER
}
