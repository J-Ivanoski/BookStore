package mk.ukim.finki.emt.model.search;


/**
 * @author Riste Stojanov
 */
public class BookSearchCriteria {

  String text;

  Long categoryId;


}
