/*package mk.ukim.finki.emt.persistence.impl;

import mk.ukim.finki.emt.model.jpa.Checkout;
import mk.ukim.finki.emt.model.jpa.DeliveryPackage;
import mk.ukim.finki.emt.persistence.CheckoutRepository;
import mk.ukim.finki.emt.persistence.DeliveryPackageRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by jovica on 4/6/17.
 *//*
@Repository
public class DeliveryPackageRepositoryImpl implements DeliveryPackageRepository {

    public DeliveryPackageRepository deliveryPackageRepositoryRepository;
    public DeliveryPackageRepositoryImpl(DeliveryPackageRepositoryImpl deliveryPackageRepositoryRepository) {
        this.deliveryPackageRepositoryRepository = deliveryPackageRepositoryRepository;
    }


    @Override
    public List<DeliveryPackage> findAll() {
        return null;
    }

    @Override
    public List<DeliveryPackage> findById(Long checkoutId) {
        return null;
    }
}*/