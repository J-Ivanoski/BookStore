package mk.ukim.finki.emt.model.exceptions;


/**
 * @author Riste Stojanov
 */
public class CategoryInUseException extends Exception {
}
