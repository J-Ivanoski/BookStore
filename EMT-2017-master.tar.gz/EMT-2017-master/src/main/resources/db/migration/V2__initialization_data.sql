INSERT INTO store.categories (name, parent_id)
VALUES ('Java', null);